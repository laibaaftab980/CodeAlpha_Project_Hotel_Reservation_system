
import java.util.Date;
public class Reservation {
    private int Res_ID;
    private Customer customer;
    private Room room;
    private Date date_check_in;
    private Date date_check_out;
    private boolean ispaid;
    
    public Reservation(int Res_ID,Customer customer,
    Room room,Date date_check_in,Date date_check_out){
        this.Res_ID = Res_ID;
        this.customer = customer;
        this.date_check_in = date_check_in;
        this.date_check_out = date_check_out;
        this.room = room;
        this.ispaid = false;
    }
    public int getRes_ID(){
        return Res_ID;
    }
    public Customer getCustomer(){
        return customer;
    }
    public Room getrRoom(){
        return room;
    }
    public Date getDate_checkin(){
        return date_check_in;
    }
    public Date getDate_checkout(){
        return date_check_out;
    }
    public void markasIsPaid(){
        this.ispaid = true;
    }
    public boolean IsPaid(){
        return ispaid;
    }
    
}
