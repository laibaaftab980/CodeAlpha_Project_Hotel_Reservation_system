import java.util.Scanner;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        Scanner in= new Scanner(System.in);
        Hotel hotel = new Hotel();
        
        //backend 
        hotel.addroom(new SingleRoom(101, 50000));
        hotel.addroom(new SingleRoom(102, 50000));
        hotel.addroom(new SingleRoom(103, 50000));
        hotel.addroom(new SingleRoom(104, 50000));
        hotel.addroom(new SingleRoom(105, 50000));

        hotel.addroom(new Double_Room(201, 100000));
        hotel.addroom(new Double_Room(202, 100000));
        hotel.addroom(new Double_Room(203, 100000));
        hotel.addroom(new Double_Room(204, 100000));
        hotel.addroom(new Double_Room(205, 100000));

        hotel.addroom(new Deluxe_Room(301, 700000, true));
        hotel.addroom(new Deluxe_Room(302, 700000, false));
        hotel.addroom(new Deluxe_Room(303, 700000, false));
        hotel.addroom(new Deluxe_Room(304, 700000, true));
        hotel.addroom(new Deluxe_Room(305, 700000, true));

        hotel.addroom(new Suite_Room(401, 900000, false));
        hotel.addroom(new Suite_Room(402, 900000, false));
        hotel.addroom(new Suite_Room(403, 900000, false));
        hotel.addroom(new Suite_Room(404, 900000, true));
        hotel.addroom(new Suite_Room(405, 900000, true));

        boolean add= true;
        while (add) {
             int id;
             String name;
             String email;
            System.out.println("Enter Customer ID");
            id = in.nextInt();
            System.out.println("Enter Customer name");
            name = sc.nextLine();
            System.out.println("Enter Customer E_mail");
            email = sc.nextLine();
            Customer customer = new Customer(id, name, email);
            System.out.println("Select Room Category to search \n"+
            "*-Single Room \n"+
            "*-Double Room \n"+
            "*-Deluxe Room \n"+
            "*-Suite Room \n");
            String category = sc.nextLine();
            
            List<Room> avail_room = hotel.SearchAvailRoom(category); 
            if(avail_room.isEmpty()){
                System.out.println("No Available Rooms in this category");
                continue;
            }
            //available rooms 
            System.out.println("************************************************************");
            System.out.println(" Available Rooms ");
            for(int i = 0 ; i< avail_room.size();i++){
                Room room = avail_room.get(i);
                System.out.println((i+1)+" Room ID " +room.getR_ID() +" Price $ " +room.getPrice()+" Category " +room.getR_cat());

            }
            System.out.println("************************************************************");

            System.out.println("\nEnter the no of reservation do you want");
            int room_choice= in.nextInt();
            
            if(room_choice<1||room_choice>avail_room.size()){
                System.out.println("Invalid Choice");
                continue;
            }
            Room SelectedRoom = avail_room.get(room_choice-1);
            Reservation reservation = hotel.CreateReservation(customer, SelectedRoom, null, null);
            if(reservation !=null){
                System.out.println("Reservation successfully created \n Reservation ID = "+reservation.getRes_ID());
            }else
            {
                System.out.println("Room not available");
                continue;
            }
            //res deatails 
            System.out.println("*************************************************************");
            System.out.println("           Your Reservation Details");
            System.out.println("           Customer Name = " +reservation.getCustomer().getName());
            System.out.println("           Resevation ID = " +reservation.getRes_ID());
            System.out.println("           Room ID = " +reservation.getrRoom().getR_ID());
            System.out.println("           Category = " +reservation.getrRoom().getR_cat());
            System.out.println("           Price per Reservation= " +reservation.getrRoom().getPrice());
            System.out.println("           Total Price = " +reservation.getrRoom().getPrice()*room_choice +"\nTotal Room ="+room_choice);
            System.out.println("**************************************************************");
            
            System.out.println("Do you want to proceed for further payment procedure \nY/N");
            String pay_choice = sc.nextLine();

            if(pay_choice.equalsIgnoreCase("Y")){
                hotel.Payment(reservation);
                System.out.println("Payment successfully processed for Reservation ID = "+reservation.getRes_ID());
            }else{
                System.out.println("Payment not processed");
            }

            System.out.println("Do you want to add customer with new Reservation:? Y/N");
            String new_choice= sc.nextLine();

            if(!new_choice.equalsIgnoreCase("y")){
                add = false;
            }


        }
        System.out.println("Thanks for using Hotel Reservation System ");
        sc.close();
        in.close();        
    }
}
