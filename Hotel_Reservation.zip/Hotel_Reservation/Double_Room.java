
public class Double_Room extends Room {
    public Double_Room(int R_ID,double price){
        super(R_ID, "double",price);
    }
    @Override
    public String toString(){
    return super.toString() ;
}
    
}
