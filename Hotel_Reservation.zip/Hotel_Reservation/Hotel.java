
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Date;
import java.util.Map;

public class Hotel {
    private List<Room> rooms = new ArrayList<Room>();
    private Map<Integer , Reservation> reservations = new HashMap<>();
    private int next_res_ID = 1;

 
    public void addroom(Room room){
        rooms.add(room);
    }
    public List<Room> SearchAvailRoom(String category){
        List<Room> avail_room= new ArrayList<Room>();
        for(Room room : rooms){
            if(room.getR_cat().equalsIgnoreCase(category)&&room.getAvail()){
             avail_room.add(room);   
            }
            
        } 
        return avail_room;
        
    } 
    public Reservation CreateReservation(Customer customer,Room room,Date check_in,Date date_check_out){
        if(room.getAvail()){
            room.bookRoom();
            Reservation reservation = new Reservation(next_res_ID++, customer, room, date_check_out, date_check_out);
            return reservation;
        }
        return null;

    }

    public Reservation getResbyID(int Res_ID){
        return reservations.get(Res_ID);
    }

    public void Payment(Reservation reservation){
        reservation.markasIsPaid();

    }
}
