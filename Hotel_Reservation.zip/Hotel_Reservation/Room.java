
public class Room {
    private int R_ID;
    private String R_cat;
    private double price;
    private boolean is_avail;

    public Room(int R_ID,String R_cat,double price){
        this.R_ID = R_ID;
        this.R_cat = R_cat;
        this.price = price;
        this.is_avail = true;
    }
    public int getR_ID(){
        return R_ID;
    }
    public String getR_cat(){
        return R_cat;
    }
    public double getPrice(){
        return price;
    }
    public boolean getAvail(){
        return is_avail;
    }
    public void bookRoom(){
        this.is_avail=false;

    }
    public void releaseRoom(){
        this.is_avail=true;
    }

    @Override
    public String toString() {
        return "Room ID: " + R_ID + 
               ", Category: " + R_cat + 
               ", Price: $" + price + 
               ", Available: " + (is_avail ? "Yes" : "No");
    }
    
}

