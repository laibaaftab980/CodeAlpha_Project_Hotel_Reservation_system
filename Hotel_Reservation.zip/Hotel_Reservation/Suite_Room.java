

public class Suite_Room extends Room{
    private boolean hasLivingArea;
    public Suite_Room(int R_ID,double price,boolean hasLivingArea){
        super(R_ID, "Suite",price);
        this.hasLivingArea = hasLivingArea;
    }
    public boolean gethasLivingArea(){
        return hasLivingArea;
    }

    @Override
    public String toString(){
    return super.toString() +", Living Area " + (hasLivingArea? "Yes":"No");
}
}

