
public class Customer {
    private int C_ID;
    private String name;
    private String Contact_Info;
   
    public Customer(int C_ID,String name,String Contact_Info){
       this.C_ID=C_ID;
       this.name=name;
       this.Contact_Info=Contact_Info;      
    }
    public int getID(){
       return C_ID;
    }
    public String getName(){
       return name;
    }
    
    public String getContact_info(){
       return Contact_Info;
    }   
}