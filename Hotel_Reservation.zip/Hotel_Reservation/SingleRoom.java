
public class SingleRoom extends Room {
    public SingleRoom(int R_ID,double price){
        super(R_ID,"Single",price);  
    }
    @Override
    public String toString(){
    return super.toString();
}
}

