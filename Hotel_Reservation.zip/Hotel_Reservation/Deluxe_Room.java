
public class Deluxe_Room extends Room {
    private boolean hasJacuzzi;
    public Deluxe_Room(int R_ID,double price,boolean hasJacuzzi){
        super(R_ID, "Deluxe",price);
        this.hasJacuzzi = hasJacuzzi;
    }
    public boolean gethasJacuzzi(){
        return hasJacuzzi;
    }
     @Override
     public String toString(){
     return super.toString() +", Jacuzzi " + (hasJacuzzi? "Yes":"No") ;
 }
}
